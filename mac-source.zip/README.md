# Exion bot

Windows x64 桌面版，基于 AstrBot v4.29.3。版本 0.1.4。

## 使用

运行 YixuanAI-Setup-0.1.4-x64.exe，可选择 D 盘安装位置。
打开“Exion bot”，选择安装目录以外的新数据文件夹（例如 D:\奕炫机器人数据）。点击启动；第一次启动可能需要一至两分钟。
控制台显示初始账号 astrbot 和随机临时密码。进入管理界面登录，按提示修改密码。
在模型提供商配置并测试模型，在配置文件中选用；再创建所需平台机器人。

关闭窗口会留在托盘。停止按钮仅停止本软件的后台；托盘退出会停止后台并退出软件。
备份前需停止后台；将备份保存到数据目录外。卸载程序不会主动删除自选数据目录。

## 首版范围

集成 Python 与基础依赖；支持管理界面、日志、启动/停止/重启、托盘、独立数据、停止后备份。
不包含个人账号桥接程序、模型额度、语音服务、插件专用依赖、浏览器下载和业务系统连接。
暂不支持一键迁移旧机器人的资料或软件内自动升级。通过新版安装包升级桌面发行版；不要在 WebUI 切换核心版本。
管理后台只监听 127.0.0.1，并使用本次启动可用端口。公网回调平台需要独立配置部署；此版优先用于长连接或本机测试。

## 构建

1. 使用 Node.js 22+ 与 pnpm，执行 pnpm install --ignore-scripts。
2. 执行 node node_modules/electron/install.js 下载 Electron。
3. vendor/AstrBot-4.29.3 为上游源码；保留原始许可证。将同版本官方 WebUI dist 放入该目录 astrbot/dashboard/dist。
4. runtime/python 为可重定位 CPython 3.12 Windows x64，Lib/site-packages 安装 AstrBot 4.29.3 的依赖。运行时通过 app/backend.py 优先加载 vendor 的源码，不使用用户现有安装。
5. 执行 python scripts/package_sources.py 生成对应源码包；执行 pnpm dist 构建 NSIS 安装包。
6. 若采用本发行版完整源码归档，其中包含实际使用的运行环境依赖清单 runtime-dependencies.txt。依赖各自保留许可证。

桌面代码位于 app/，品牌图片位于 assets/，Electron Builder 配置位于 package.json。
开发运行：pnpm start。测试请使用单独数据目录，不要接入真实群聊。
