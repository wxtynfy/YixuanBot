from pathlib import Path
import json,zipfile
r=Path(r'D:\work\AstrBot-desktop');site=r/'runtime/python/Lib/site-packages'
names=['lark_oapi','openai','anthropic'];count=0
with zipfile.ZipFile(site/'bundled_sdks.zip','w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
 for name in names:
  z.writestr(name+'/',b'')
  for p in (site/name).rglob('*'):
   if p.is_dir() and '__pycache__' not in p.parts:z.writestr(p.relative_to(site).as_posix()+'/',b'')
   if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
    assert p.suffix not in ['.pyd','.dll'],str(p)
    z.write(p,p.relative_to(site));count+=1
(site/'bundled_sdks.pth').write_text('bundled_sdks.zip\n',encoding='ascii')
p=r/'package.json';o=json.loads(p.read_text(encoding='utf-8-sig'))
for resource in o['build']['extraResources']:
 if resource['from']=='runtime':
  resource['filter']+=['!python/Lib/site-packages/'+name+'/**' for name in names]
 if resource['from']=='vendor/AstrBot-4.29.3':resource['filter']+=['!dashboard/**','!tests/**','!docs/**','!**/__pycache__/**','!**/*.pyc']
p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('SDK files consolidated:',count,'Archive bytes:',(site/'bundled_sdks.zip').stat().st_size)
