from pathlib import Path
import os,zipfile
root=Path(__file__).resolve().parents[1]
with zipfile.ZipFile(root/'source-distribution.zip','w',zipfile.ZIP_DEFLATED) as z:
 for item in ['app','assets','scripts','vendor/AstrBot-4.29.3']:
  for folder,dirs,files in os.walk(root/item):
   dirs[:]=[d for d in dirs if d not in ['.git','__pycache__','node_modules']]
   for name in files:
    f=Path(folder)/name
    if f.suffix!='.pyc':z.write(f,f.relative_to(root))
 for item in ['package.json','pnpm-lock.yaml','LICENSE','NOTICE.md','README.md','runtime-dependencies.txt','toolbox/LICENSE']:
  if (root/item).exists():z.write(root/item,item)
print(root/'source-distribution.zip')
