from pathlib import Path
import re,json,shutil
r=Path(r'D:\work\AstrBot-desktop');d=r/'vendor/AstrBot-4.29.3/dashboard'
# Keep plugin artwork independent of the app favicon.
shutil.copyfile(r/'.test/upstream-dist-011/favicon.svg',d/'public/plugin-default.svg')
for p in (d/'src').rglob('*'):
 if p.suffix in ('.vue','.ts','.js','.json'):
  s=p.read_text(encoding='utf-8-sig');s=s.replace('Exion bot','Exion bot').replace('Exion bot WebUI','Exion bot')
  s=s.replace('import defaultPluginIcon from "/favicon.svg"','import defaultPluginIcon from "/plugin-default.svg"')
  if p.suffix=='.json' and 'i18n' in p.parts and p.name!='about.json':
   # Change display values, never keys, repository URLs, or package identifiers.
   obj=json.loads(s)
   def walk(o):
    if isinstance(o,dict):return {k:walk(v) for k,v in o.items()}
    if isinstance(o,list):return [walk(v) for v in o]
    if isinstance(o,str):return re.sub(r'https?://[^\s<>"\x27]+|\bAstrBot\b',lambda m:m[0] if m[0].startswith('http') else 'Exion bot',o)
    return o
   s=json.dumps(walk(obj),ensure_ascii=False,indent=2)+'\n'
  p.write_text(s,encoding='utf-8-sig')
p=d/'src/layouts/full/FullLayout.vue';s=p.read_text(encoding='utf-8-sig')
s=s.replace('import ReadmeDialog from "@/components/shared/ReadmeDialog.vue";\n','')
s=re.sub(r'const FIRST_NOTICE_SEEN_KEY = .*?;\n','',s)
s=s.replace('const showFirstNoticeDialog = ref(false);\n','')
a=s.index('const maybeShowFirstNotice =');b=s.index('onMounted(() => {',a);s=s[:a]+s[b:]
s=s.replace('    await maybeShowFirstNotice();\n','')
s=re.sub(r'\s*<ReadmeDialog\s+:show="showFirstNoticeDialog".*?/>','',s,flags=re.S)
p.write_text(s,encoding='utf-8-sig')
for p in [d/'index.html',*list((r/'app').glob('*')),r/'package.json',r/'README.md',r/'NOTICE.md']:
 if p.is_file():
  s=p.read_text(encoding='utf-8-sig').replace('Exion bot','Exion bot').replace('0.1.2','0.1.3');p.write_text(s,encoding='utf-8-sig')
# Keep the same appId and preferences/data paths so upgrade preserves settings.
print('Renamed UI and app; removed first notice; restored plugin fallback icon')

