"""Verify isolated backend login and orderly shutdown without real services."""
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import time
import urllib.request

root=Path(__file__).resolve().parents[1]
resources=Path(sys.argv[1]) if len(sys.argv)>1 else root
packaged=resources!=root
test=root/'.test'/('api-'+secrets.token_hex(4))
test.mkdir(parents=True)
(test/'data').mkdir()
(test/'temp').mkdir()
with socket.socket() as sock:
    sock.bind(('127.0.0.1',0))
    port=sock.getsockname()[1]
password=secrets.token_urlsafe(18)
env=os.environ.copy()
env.update(ASTRBOT_ROOT=str(test),ASTRBOT_DASHBOARD_INITIAL_PASSWORD=password,DASHBOARD_HOST='127.0.0.1',DASHBOARD_PORT=str(port),PYTHONUTF8='1',TEMP=str(test/'temp'),TMP=str(test/'temp'))
backend=resources/('backend' if packaged else 'vendor/AstrBot-4.29.3')
entry=resources/'backend-entry.py' if packaged else root/'app/backend.py'
result={}
with (test/'backend.log').open('wb') as log:
    p=subprocess.Popen([str(resources/'runtime/python/python.exe'),'-u',str(entry),str(backend)],cwd=test,env=env,stdin=subprocess.PIPE,stdout=log,stderr=log)
    try:
        base=f'http://127.0.0.1:{port}'
        deadline=time.time()+180
        while time.time()<deadline:
            if p.poll() is not None:raise RuntimeError('Backend exited before readiness')
            try:
                with urllib.request.urlopen(base,timeout=1) as r:
                    if r.status==200:break
            except Exception:time.sleep(.5)
        else:raise RuntimeError('Readiness timeout')
        request=urllib.request.Request(base+'/api/auth/login',data=json.dumps({'username':'astrbot','password':password}).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(request,timeout=10) as r:reply=json.load(r)
        result['login_status']=reply.get('status')
        assert reply.get('status')=='ok',str(reply.keys())
        config=json.loads((test/'data/cmd_config.json').read_text(encoding='utf-8-sig'))
        assert not config.get('provider') and not config.get('platform')
        result['clean_configuration']=True
        p.stdin.write(b'STOP\n');p.stdin.flush()
        p.wait(timeout=20)
        result['graceful_exit']=p.returncode==0
        assert p.returncode==0
    finally:
        if p.poll() is None:p.kill();p.wait()
(test/'result.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result),test)
