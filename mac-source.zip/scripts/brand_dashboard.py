from pathlib import Path
import json,base64
r=Path(r'D:\work\AstrBot-desktop'); v=r/'vendor/AstrBot-4.29.3'; d=v/'dashboard'
def edit(p,a,b):
 s=p.read_text(encoding='utf-8'); assert a in s,str(p); p.write_text(s.replace(a,b),encoding='utf-8')
logo=base64.b64encode((r/'assets/logo.png').read_bytes()).decode()
(d/'public/favicon.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128"><image width="128" height="128" href="data:image/png;base64,{logo}"/></svg>',encoding='utf-8')
(d/'src/components/chat/ChatUILogo.vue').write_text('<template>\n  <img src="/favicon.svg" alt="Exion bot" style="object-fit:contain;border-radius:6px" />\n</template>\n',encoding='utf-8')
edit(d/'src/layouts/full/vertical-sidebar/VerticalSidebar.vue','>AstrBot</span>','>Exion bot</span>')
for p in [d/'src/components/shared/Logo.vue',d/'src/views/authentication/auth/LoginPage.vue',d/'src/views/authentication/auth/SetupPage.vue']:
 edit(p,'alt="AstrBot Logo"','alt="Exion bot"')
for locale in (d/'src/i18n/locales').iterdir():
 for rel in ['features/auth.json','features/welcome.json','core/header.json']:
  p=locale/rel
  if p.exists():
   s=p.read_text(encoding='utf-8');p.write_text(s.replace('AstrBot','Exion bot'),encoding='utf-8')
p=d/'src/views/WelcomePage.vue';s=p.read_text(encoding='utf-8');start=s.index('      <v-row class="px-4 mt-4">');end=s.index('      <v-row v-if="showAnnouncement"',start);s=s[:start]+s[end:];p.write_text(s,encoding='utf-8')
edit(d/'index.html','AstrBot','Exion bot')
notice='''# 欢迎使用Exion bot

连接对话模型与聊天平台，管理人格、知识库和插件。

## 关于本软件

这是基于 **AstrBot v4.29.3** 修改的非官方桌面发行版，管理界面和桌面启动器已作定制。AstrBot 为上游开源项目，本发行版不代表 AstrBot 官方。

上游版权和 **AGPL-3.0-or-later** 许可证保留。对应源码随安装包提供，可通过桌面控制台的“查看随附源码”获取；许可证和修改说明见源码中的 LICENSE、NOTICE.md。

上游项目：https://github.com/AstrBotDevs/AstrBot

首次使用请先添加模型，再接入聊天平台。模型 API 和其他第三方服务按各服务商规则使用。
'''
for p in v.glob('FIRST_NOTICE*.md'):p.write_text(notice,encoding='utf-8')
for rel in ['package.json','app/index.html','README.md','NOTICE.md']:
 p=r/rel;s=p.read_text(encoding='utf-8');p.write_text(s.replace('0.1.1','0.1.2'),encoding='utf-8')
with (r/'NOTICE.md').open('a',encoding='utf-8') as f:f.write('\n0.1.2 修改：后台品牌图标、名称、首次介绍已定制，移除欢迎页相关资源卡片。保留上游许可证及源码。\n')
print('Branding source updated')
