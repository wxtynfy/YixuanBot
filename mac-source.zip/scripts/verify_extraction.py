"""Check that the NSIS extractor reproduced the complete packaged file tree."""
from pathlib import Path
import hashlib
import json
import sys

expected=Path(sys.argv[1]).resolve()
actual=Path(sys.argv[2]).resolve()
failures=[]
count=0
for source in expected.rglob('*'):
    if not source.is_file() or '__pycache__' in source.parts or source.suffix=='.pyc':
        continue
    relative=source.relative_to(expected)
    target=actual/relative
    count+=1
    if not target.is_file():
        failures.append(str(relative)+' missing')
    elif source.stat().st_size!=target.stat().st_size:
        failures.append(str(relative)+' size mismatch')
    elif source.suffix in ['.exe','.dll','.asar','.py'] and hashlib.file_digest(source.open('rb'),'sha256').digest()!=hashlib.file_digest(target.open('rb'),'sha256').digest():
        failures.append(str(relative)+' hash mismatch')
print(json.dumps({'files_checked':count,'failures':failures},ensure_ascii=False))
sys.exit(bool(failures))
