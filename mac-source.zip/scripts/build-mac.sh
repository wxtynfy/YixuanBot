#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ "$(uname -s)" == Darwin && "$(uname -m)" == arm64 ]] || { echo "Requires an Apple Silicon Mac"; exit 1; }
command -v uv >/dev/null || { echo "Install uv first: https://docs.astral.sh/uv/getting-started/installation/"; exit 1; }
command -v node >/dev/null || { echo "Install Node.js 22 or newer"; exit 1; }
command -v pnpm >/dev/null || { echo "Install pnpm"; exit 1; }
# Managed standalone Python, not a venv pointing at the build machine's Python.
export UV_PYTHON_INSTALL_DIR="$PWD/.build/python"
uv python install 3.12
PYTHON_DIR="$(dirname "$(dirname "$(uv python find --managed-python 3.12)")")"
mkdir -p runtime
[[ ! -e runtime/python ]] || { echo "runtime/python already exists; inspect it before rebuilding"; exit 1; }
cp -RL "$PYTHON_DIR" runtime/python
uv pip install --break-system-packages --python "$PWD/runtime/python/bin/python3" "$PWD/vendor/AstrBot-4.29.3"
# Bundle the official native database service.
mkdir -p toolbox
curl --fail --location --retry 3 --output toolbox/toolbox https://storage.googleapis.com/mcp-toolbox-for-databases/v1.15.0/darwin/arm64/toolbox
chmod +x toolbox/toolbox
toolbox/toolbox --version
shasum -a 256 toolbox/toolbox > toolbox/SHA256.txt
runtime/python/bin/python3 -c 'import mcp, sqlite3; print("Database runtime imports OK")'
runtime/python/bin/python3 scripts/test_enterprise_live.py
# Source and built dashboard are provided in vendor; exclude all personal data.
runtime/python/bin/python3 scripts/package_sources.py
pnpm install --frozen-lockfile --ignore-scripts
node node_modules/electron/install.js
CSC_IDENTITY_AUTO_DISCOVERY=false pnpm run dist:mac
printf '\nBuild finished. Test release/*.dmg on a separate Mac before distribution.\n'
