"""Exercise the bundled real Toolbox against isolated simulated records."""
import asyncio, json, os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

ROOT = Path(__file__).resolve().parents[1]
async def verify(url, demo):
    async with streamablehttp_client(url) as (reader, writer, _):
        async with ClientSession(reader, writer) as session:
            await session.initialize()
            names = {x.name for x in (await session.list_tools()).tools}
            assert {'query_demo_order', 'query_demo_inventory'} <= names, names
            async def query(name, args):
                result = await session.call_tool(name, args)
                assert not result.isError, result
                return json.dumps(result.model_dump(), ensure_ascii=False)
            before = await query('query_demo_order', {'order_id':'DEMO001'})
            assert '待发货' in before, before
            assert '100' in await query('query_demo_inventory', {'sku':'SKU001'})
            subprocess.run([sys.executable, str(ROOT/'app/enterprise_demo.py'), str(demo), 'update'], check=True, capture_output=True)
            after = await query('query_demo_order', {'order_id':'DEMO001'})
            assert '已发货' in after, after
            assert '88' in await query('query_demo_inventory', {'sku':'SKU001'})
            for order in ['missing', "' OR 1=1 --"]:
                result = await query('query_demo_order', {'order_id':order})
                assert 'DEMO001' not in result, result
            print('PASS: initialize, tool discovery, order/inventory lookup, live update, missing record, parameter injection')

(ROOT/'.test').mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='enterprise-', dir=ROOT/'.test') as folder:
    demo=Path(folder)
    subprocess.run([sys.executable,str(ROOT/'app/enterprise_demo.py'),folder],check=True,capture_output=True)
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
    with (demo/'server.log').open('w') as log:
        p=subprocess.Popen([str(ROOT/('toolbox/toolbox.exe' if sys.platform=='win32' else 'toolbox/toolbox')),'--config',str(demo/'tools.yaml'),'--address','127.0.0.1','--port',str(port)],stdout=log,stderr=log)
        try:
            for _ in range(100):
                if p.poll() is not None: raise RuntimeError((demo/'server.log').read_text())
                try:
                    with socket.create_connection(('127.0.0.1',port),timeout=.2):break
                except OSError:time.sleep(.2)
            asyncio.run(verify(f'http://127.0.0.1:{port}/mcp',demo))
        finally:
            p.terminate();p.wait(timeout=10)
    print('PASS: service shutdown')
