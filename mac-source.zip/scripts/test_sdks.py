import sys,time
from pathlib import Path
start=time.perf_counter()
z=Path(sys.executable).parent/'Lib/site-packages/bundled_sdks.zip'
sys.path.insert(0,str(z))
import lark_oapi,openai,anthropic
from lark_oapi.api.im.v1 import CreateMessageRequest,CreateMessageRequestBody
from openai.types.chat import ChatCompletion
from anthropic.types import Message
for m in [lark_oapi,openai,anthropic]:
 assert 'bundled_sdks.zip' in m.__file__,m.__file__
client=openai.OpenAI(api_key='test-only');client.close()
client=anthropic.Anthropic(api_key='test-only');client.close()
req=CreateMessageRequest.builder().receive_id_type('chat_id').request_body(CreateMessageRequestBody.builder().receive_id('test').msg_type('text').content('{}').build()).build()
assert req is not None
print('SDK ZIP imports and client construction passed; seconds:',round(time.perf_counter()-start,2))
