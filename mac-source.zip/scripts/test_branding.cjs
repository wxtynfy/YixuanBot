const {app,BrowserWindow}=require('electron');
const fs=require('fs'),path=require('path'),net=require('net'),crypto=require('crypto'),{spawn}=require('child_process');
const root=path.resolve(__dirname,'..'),test=path.join(root,'.test','branding-014');
fs.mkdirSync(test,{recursive:true});app.setPath('userData',path.join(test,'electron'));app.disableHardwareAcceleration();
let child,win;const sleep=ms=>new Promise(r=>setTimeout(r,ms));
app.whenReady().then(async()=>{try{
 const server=net.createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;await new Promise(r=>server.close(r));
 const password='Aa1!'+crypto.randomBytes(20).toString('hex');const logfile=fs.openSync(path.join(test,'backend.log'),'w');
 child=spawn(path.join(root,'runtime/python/python.exe'),['-u',path.join(root,'app/backend.py'),path.join(root,'vendor/AstrBot-4.29.3')],{cwd:test,windowsHide:true,env:{...process.env,ASTRBOT_ROOT:test,ASTRBOT_DASHBOARD_INITIAL_PASSWORD:password,DASHBOARD_HOST:'127.0.0.1',DASHBOARD_PORT:String(port),PYTHONUTF8:'1'},stdio:['pipe',logfile,logfile]});
 const url=`http://127.0.0.1:${port}`;let ready=false;for(let i=0;i<120;i++){try{const response=await fetch(url); if(response.ok){ready=true;break} console.log('HTTP',response.status)}catch(e){console.log(e.message)}await sleep(1000)}if(!ready)throw Error('Backend timeout');
 win=new BrowserWindow({width:1380,height:950,show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
 await win.loadURL(url+'/#/auth/login');await sleep(2500);
 const auth=await (await fetch(url+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'astrbot',password})})).json();if(auth.status!=='ok')throw Error('Login failed');
 await win.webContents.executeJavaScript(`localStorage.setItem('token',${JSON.stringify(auth.data.token)});localStorage.setItem('user','astrbot');localStorage.removeItem('astrbot:first_notice_seen:v1')`);
 await win.loadURL(url+'/#/auth/setup');await sleep(2000);
 fs.writeFileSync(path.join(test,'setup.png'),(await win.webContents.capturePage()).toPNG());
 const setup=await win.webContents.executeJavaScript('document.body.innerText');if(!setup.includes('Exion bot'))throw Error('Setup brand missing');
 await win.loadURL(url+'/#/welcome');await sleep(3000);
 const check=await win.webContents.executeJavaScript(`({title:document.title,text:document.body.innerText,brand:document.querySelector('.dashboard-sidebar-brand-name')?.textContent,images:[...document.images].filter(i=>i.src.endsWith('/favicon.svg')).map(i=>({loaded:i.complete&&i.naturalWidth>0,src:i.getAttribute('src')}))})`);
 if(check.text.includes('首次提示'))throw Error('Unexpected first notice');
 if(check.brand!=='Exion bot'||check.text.includes('相关资源')||!check.text.includes('欢迎使用 Exion bot')||!check.images.length||check.images.some(i=>!i.loaded))throw Error(JSON.stringify(check));
 fs.writeFileSync(path.join(test,'welcome.png'),(await win.webContents.capturePage()).toPNG());
 const pluginIcon=await (await fetch(url+'/plugin-default.svg')).text();if(pluginIcon.includes('data:image/png'))throw Error('Plugin fallback still branded');
 await win.loadURL(url+'/#/providers');await sleep(3500);
 const clicked=await win.webContents.executeJavaScript(`(()=>{const b=[...document.querySelectorAll('button')].find(b=>b.innerText.includes('新增')||b.innerText.includes('添加模型提供商'));if(b){b.click();return true}return false})()`);
 if(!clicked)throw Error('Provider add button not found');await sleep(1200);
 const dialog=await win.webContents.executeJavaScript(`document.querySelector('.source-dialog')?.innerText||''`);
 if(!dialog.includes('OpenAI')||dialog.includes('赞助商')||dialog.includes('MiraRouter')||dialog.includes('SSYCloud'))throw Error('Unexpected provider dialog: '+dialog);
 fs.writeFileSync(path.join(test,'providers.png'),(await win.webContents.capturePage()).toPNG());
 fs.writeFileSync(path.join(test,'result.json'),JSON.stringify({passed:true,title:check.title,brand:check.brand,resourceCardsRemoved:true,firstNoticeRemoved:true,pluginIconRestored:true,images:check.images},null,2));
 console.log('Branding UI verification passed');
 }catch(e){fs.writeFileSync(path.join(test,'error.txt'),e.stack);console.error(e);process.exitCode=1}finally{if(child){child.stdin.end('STOP\n');await Promise.race([new Promise(r=>child.on('exit',r)),sleep(20000)])}app.quit()}});



