; Exercise the same NSIS extractor used by the production installer.
; This does not create shortcuts, registry entries, or an uninstaller.
Unicode true
RequestExecutionLevel user
SilentInstall silent
Name "Yixuan installer extraction verification"
OutFile "${TEST_EXE}"
!addplugindir "${PLUGIN_DIR}"
Section
SetOutPath "${DESTINATION}"
Nsis7z::Extract "${PAYLOAD}"
SectionEnd
