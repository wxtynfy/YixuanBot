const {app,BrowserWindow,WebContentsView,Tray,Menu,ipcMain,dialog,shell,nativeImage}=require('electron');
const fs=require('fs'),path=require('path'),net=require('net'),crypto=require('crypto');
const {spawn}=require('child_process');
const NAME='Exion bot';app.setName(NAME);app.disableHardwareAcceleration();
// Separate desktop preferences from the user's existing AstrBot installation.
app.setPath('userData',process.env.YIXUAN_TEST_HOME||path.join(app.getPath('appData'),'YixuanAI'));
const home=app.getPath('userData'),settingsFile=path.join(home,'desktop.json');
fs.mkdirSync(home,{recursive:true});
let cfg={};try{cfg=JSON.parse(fs.readFileSync(settingsFile,'utf8'))}catch{}
let win,view,tray,child=null,phase='stopped',error='',quitting=false,port=0,logs=[],logStream,initialPassword='',busy=false;
const root=app.isPackaged?process.resourcesPath:path.join(__dirname,'..');
const backend=path.join(root,app.isPackaged?'backend':'vendor/AstrBot-4.29.3');
const python=path.join(root,process.platform==='win32'?'runtime/python/python.exe':'runtime/python/bin/python3');
const {Toolbox}=require('./managed-toolbox.cjs');
const toolbox=new Toolbox(path.join(root,'toolbox',process.platform==='win32'?'toolbox.exe':'toolbox'));
const icon=path.join(__dirname,process.platform==='win32'?'../assets/icon.ico':'../assets/logo.png');
function state(){return {name:NAME,phase,error,dataDir:cfg.dataDir||'',url:port?`http://127.0.0.1:${port}`:'',initialPassword,version:'4.29.3',logs:logs.slice(-120)}}
function send(){if(quitting)return;if(win&&!win.isDestroyed())win.webContents.send('desktop:state',state());if(tray&&!tray.isDestroyed())tray.setContextMenu(Menu.buildFromTemplate([{label:'打开 '+NAME,click:()=>{win.show();win.focus()}},{label:phase==='running'?'后台运行中':'后台未运行',enabled:false},{type:'separator'},{label:'退出并停止机器人',click:()=>app.quit()}]));}
function line(s){s=s.replace(/\x1b\[[0-9;]*m/g,'');logs.push(s);if(logs.length>400)logs.shift();logStream?.write(s);if(win&&!win.isDestroyed())win.webContents.send('desktop:log',s)}
function save(){fs.writeFileSync(settingsFile,JSON.stringify(cfg,null,2))}
function freePort(){return new Promise((res,rej)=>{const s=net.createServer();s.once('error',rej);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>res(p))})})}
async function start(){
 if(child||busy)return state();if(!cfg.dataDir)throw Error('请先选择独立的数据目录。');busy=true;error='';phase='starting';send();
 try{
  if(cfg.managedToolbox){const url=await toolbox.start(cfg.managedToolbox);require('./enterprise.cjs').save(cfg.dataDir,{url,token:'',clearToken:true,active:true});}
  const d=cfg.dataDir;fs.mkdirSync(path.join(d,'data'),{recursive:true});fs.writeFileSync(path.join(d,'.astrbot'),'');fs.mkdirSync(path.join(d,'logs'),{recursive:true});fs.mkdirSync(path.join(d,'temp'),{recursive:true});
  logStream=fs.createWriteStream(path.join(d,'logs','desktop.log'),{flags:'a'});
  if(!fs.existsSync(python)||!fs.existsSync(path.join(backend,'astrbot','__init__.py')))throw Error('安装文件不完整：缺少 Python 或 AstrBot 源码。');
  port=await freePort();const fresh=!fs.existsSync(path.join(d,'data','cmd_config.json'));
  initialPassword=fresh?crypto.randomBytes(12).toString('base64url'):'';
  const env={...process.env,PYTHONUTF8:'1',PYTHONIOENCODING:'utf-8',PYTHONUNBUFFERED:'1',PYTHONNOUSERSITE:'1',ASTRBOT_ROOT:d,DASHBOARD_HOST:'127.0.0.1',DASHBOARD_PORT:String(port),TEMP:path.join(d,'temp'),TMP:path.join(d,'temp')};
  delete env.PYTHONHOME;delete env.PYTHONPATH;
  if(initialPassword)env.ASTRBOT_DASHBOARD_INITIAL_PASSWORD=initialPassword;
  child=spawn(python,['-u',app.isPackaged?path.join(root,'backend-entry.py'):path.join(__dirname,'backend.py'),backend],{cwd:d,env,windowsHide:true,stdio:['pipe','pipe','pipe']});
  const proc=child;
  proc.stdout.on('data',b=>line(b.toString('utf8')));proc.stderr.on('data',b=>line(b.toString('utf8')));
  proc.on('error',e=>{error=e.message;phase='error';send()});
  proc.on('exit',code=>{if(child!==proc)return;child=null;port=0;if(phase!=='stopping'){phase='error';error=`后台已退出（${code}），请查看日志。`}else phase='stopped';view?.setVisible(false);logStream?.end();logStream=null;send()});
  const until=Date.now()+120000;
  while(Date.now()<until&&child===proc){
   try{const r=await fetch(`http://127.0.0.1:${port}/`,{signal:AbortSignal.timeout(1000)});if(r.ok){phase='running';await openDashboard();send();return state()}}catch{}
   await new Promise(r=>setTimeout(r,700));
  }
  throw Error('后台未在两分钟内就绪，请查看日志。');
 }catch(e){error=e.message;await stop();phase='error';send();throw e}finally{busy=false}
}
async function stop(){
 const p=child;if(!p){await toolbox.stop();phase='stopped';send();return state()}phase='stopping';send();view?.setVisible(false);
 await new Promise(resolve=>{let done=false;const end=()=>{if(!done){done=true;clearTimeout(timer);resolve()}};const timer=setTimeout(()=>{if(process.platform!=='win32'){try{p.kill('SIGKILL')}catch{}end();return}const kill=spawn('taskkill',['/PID',String(p.pid),'/T','/F'],{windowsHide:true});kill.on('exit',end);kill.on('error',end)},12000);p.once('exit',end);try{p.stdin.end('STOP\n')}catch{end()}});
 await toolbox.stop();return state();
}
function resize(){if(!view||!win)return;const [w,h]=win.getContentSize();view.setBounds({x:0,y:82,width:w,height:Math.max(1,h-82)})}
async function openDashboard(){
 if(!port)return;
 if(!view){view=new WebContentsView({webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});win.contentView.addChildView(view);
  view.webContents.setWindowOpenHandler(({url})=>{if(/^https?:/.test(url))shell.openExternal(url);return {action:'deny'}});
  view.webContents.on('will-navigate',(event,url)=>{if(new URL(url).origin!==`http://127.0.0.1:${port}`){event.preventDefault();if(/^https?:/.test(url))shell.openExternal(url)}});
 }
 resize();await view.webContents.loadURL(`http://127.0.0.1:${port}/`);view.setVisible(false);
}
const enterprise=require('./enterprise.cjs');
async function probeEnterprise(v){
 const entry=enterprise.resolve(cfg.dataDir,v);
 return new Promise((resolve,reject)=>{
  const p=spawn(python,[app.isPackaged?path.join(root,'enterprise_probe.py'):path.join(__dirname,'enterprise_probe.py')],{windowsHide:true,env:{...process.env,PYTHONUTF8:'1'},stdio:['pipe','pipe','pipe']});let output='';
  const timer=setTimeout(()=>{p.kill();reject(Error('连接测试超时'));},30000);
  p.stdout.on('data',b=>{output+=b.toString();});p.stderr.on('data',()=>{});
  p.on('error',()=>{clearTimeout(timer);reject(Error('无法启动连接测试程序'));});
  p.on('close',()=>{clearTimeout(timer);try{const r=JSON.parse(output);r.error?reject(Error(r.error)):resolve(r);}catch{reject(Error('连接测试未返回有效结果'));}});
  p.stdin.on('error',()=>{});p.stdin.end(JSON.stringify(entry));
 });
}
async function demoSetup(update=false){
 if(!cfg.dataDir)throw Error('请先选择数据目录。');if(!update&&(child||busy))throw Error('请先停止机器人，再配置演示。');
 const script=app.isPackaged?path.join(root,'enterprise_demo.py'):path.join(__dirname,'enterprise_demo.py');
 const result=await new Promise((resolve,reject)=>{const p=spawn(python,[script,path.join(cfg.dataDir,'enterprise-demo'),...(update?['update']:[])],{windowsHide:true,env:{...process.env,PYTHONUTF8:'1'}});let s='';p.stdout.on('data',b=>s+=b);p.stderr.on('data',()=>{});p.on('error',()=>reject(Error('演示初始化失败')));p.on('close',code=>{try{if(code)throw Error();resolve(JSON.parse(s));}catch{reject(Error('演示数据库操作失败'));}});});
 if(update)return '演示订单 DEMO001 已改为已发货，SKU001 库存改为88；再次查询可看到新值。';
 await toolbox.stop();cfg.managedToolbox=result.config;save();const url=await toolbox.start(result.config);enterprise.save(cfg.dataDir,{url,token:'',clearToken:true,active:true});return '演示已启用。读取配置并测试；启动机器人后可问：查询演示订单 DEMO001、查询模拟库存 SKU001。';
}
const actions={
 enterpriseDemo:()=>demoSetup(),
 enterpriseUpdate:()=>demoSetup(true),
 enterpriseImport:async()=>{if(child||busy)throw Error('请先停止机器人。');if(!cfg.dataDir)throw Error('请先选择数据目录');const r=await dialog.showOpenDialog(win,{title:'选择经审核的Toolbox YAML配置（需只读账号和权限）',filters:[{name:'Toolbox YAML',extensions:['yaml','yml']}],properties:['openFile']});if(r.canceled)return '已取消';await toolbox.stop();const source=r.filePaths[0];const url=await toolbox.start(source);cfg.managedToolbox=source;save();enterprise.save(cfg.dataDir,{url,token:'',clearToken:true,active:true});return '本机Toolbox已启动。请读取配置并测试工具；生产使用前核对数据权限。';},
 enterpriseGuide:()=>shell.openPath(path.join(root,app.isPackaged?'enterprise-guide.md':'app/enterprise-guide.md')),

 enterpriseLoad:()=>enterprise.load(cfg.dataDir),
 enterpriseTest:v=>probeEnterprise(v),
 enterpriseSave:async v=>{if(child||busy)throw Error('请先停止机器人后台，再保存，避免覆盖运行中的配置。');const result=enterprise.save(cfg.dataDir,v);cfg.managedToolbox=null;save();await toolbox.stop();return result;},

 state:()=>state(),
 choose:async()=>{if(child||busy)throw Error('请先停止后台。');const result=await dialog.showOpenDialog(win,{title:'选择独立数据目录（建议在文稿中创建独立文件夹）',properties:['openDirectory','createDirectory']});if(result.canceled)return state();const p=result.filePaths[0];if(fs.existsSync(path.join(p,'data','cmd_config.json'))&&!fs.existsSync(path.join(p,'.yixuan-desktop')))throw Error('这是已有 AstrBot 数据目录。第一版请使用新文件夹，避免影响原机器人。');if(p.toLowerCase().startsWith(root.toLowerCase()+path.sep))throw Error('请选择安装目录以外的数据文件夹。');fs.writeFileSync(path.join(p,'.yixuan-desktop'),'YixuanAI');await toolbox.stop();cfg.managedToolbox=null;cfg.dataDir=p;save();send();return state()},
 start,stop,restart:async()=>{await stop();return start()},
 dashboard:()=>{if(phase!=='running')throw Error('请先启动后台。');view.setVisible(true);return state()},
 home:()=>{view?.setVisible(false);return state()},
 folder:()=>cfg.dataDir?shell.openPath(cfg.dataDir):null,
 source:()=>shell.showItemInFolder(path.join(root,'source-distribution.zip')),
 backup:async()=>{if(child||busy)throw Error('请先停止后台，再备份数据。');if(!cfg.dataDir)throw Error('尚未设置数据目录。');const r=await dialog.showOpenDialog(win,{title:'选择备份存放位置',properties:['openDirectory','createDirectory']});if(r.canceled)return;const dest=path.join(r.filePaths[0],'奕炫机器人备份-'+new Date().toISOString().replace(/[:.]/g,'-'));if(dest.toLowerCase().startsWith(cfg.dataDir.toLowerCase()+path.sep))throw Error('备份位置不能放在数据目录内。');await fs.promises.cp(cfg.dataDir,dest,{recursive:true,filter:p=>!fs.lstatSync(p).isSymbolicLink()});return '备份完成：'+dest},
 help:()=>shell.openExternal('https://docs.astrbot.app/platform/start.html'),
 exit:()=>app.quit()
};
if(!app.requestSingleInstanceLock())app.quit();else{
 app.on('second-instance',()=>{win?.show();win?.focus()});
 app.whenReady().then(async()=>{
  Menu.setApplicationMenu(null);
  win=new BrowserWindow({width:1280,height:860,minWidth:980,minHeight:680,title:NAME,icon,backgroundColor:'#f4f6fa',webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
  win.on('resize',resize);win.on('close',e=>{if(!quitting){e.preventDefault();win.hide()}});
  tray=new Tray(nativeImage.createFromPath(icon));tray.setToolTip(NAME+' · 关闭窗口后继续运行');tray.on('double-click',()=>win.show());
  for(const [n,fn]of Object.entries(actions))ipcMain.handle('desktop:'+n,async (event,...args)=>{if(event.sender!==win.webContents)throw Error('Unauthorized');try{return {ok:true,value:await fn(...args)}}catch(e){return {ok:false,error:e.message}}});
  await win.loadFile(path.join(__dirname,'index.html'));send();
  if(cfg.dataDir&&!process.env.YIXUAN_SMOKE_DATA)start().catch(e=>line('Startup failed: '+e.message+'\n'));
  if(process.env.YIXUAN_SMOKE_DATA){try{cfg.dataDir=process.env.YIXUAN_SMOKE_DATA;fs.mkdirSync(cfg.dataDir,{recursive:true});await start();await new Promise(r=>setTimeout(r,1200));fs.writeFileSync(path.join(cfg.dataDir,'control.png'),(await win.webContents.capturePage()).toPNG());fs.writeFileSync(path.join(cfg.dataDir,'dashboard.png'),(await view.webContents.capturePage()).toPNG());const result={phase,port,version:'4.29.3',title:await win.webContents.executeJavaScript('document.title'),dashboardTitle:await view.webContents.executeJavaScript('document.title')};await stop();result.stopped=child===null;fs.writeFileSync(path.join(cfg.dataDir,'smoke.json'),JSON.stringify(result));quitting=true;app.quit()}catch(e){fs.writeFileSync(path.join(cfg.dataDir,'smoke-error.txt'),e.stack);quitting=true;await stop();app.quit()}}
 });
 app.on('before-quit',e=>{if(!quitting){e.preventDefault();quitting=true;stop().finally(()=>{if(tray&&!tray.isDestroyed())tray.destroy();tray=null;app.quit()})}});
 app.on('activate',()=>{win?.show();win?.focus()});
 app.on('window-all-closed',()=>{});
}
