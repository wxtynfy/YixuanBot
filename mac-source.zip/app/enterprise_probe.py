import asyncio,json,sys
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client
async def probe(c):
    async with streamablehttp_client(c['url'],headers=c.get('headers',{})) as (reader,writer,_):
        async with ClientSession(reader,writer) as session:
            await session.initialize()
            names=[];cursor=None
            for _ in range(10):
                result=await session.list_tools(cursor=cursor)
                names.extend(t.name for t in result.tools)
                cursor=result.nextCursor
                if not cursor:break
            return {'tools':names,'truncated':bool(cursor)}
try:
    config=json.load(sys.stdin)
    print(json.dumps(asyncio.run(asyncio.wait_for(probe(config),25))))
except Exception:
    print(json.dumps({'error':'连接测试失败：请检查服务地址、认证、TLS证书及服务是否启动。'}))
    sys.exit(1)
