import sqlite3,json,sys
from pathlib import Path
root=Path(sys.argv[1]);root.mkdir(parents=True,exist_ok=True)
db=root/'demo.sqlite3'
c=sqlite3.connect(db)
c.executescript("CREATE TABLE IF NOT EXISTS orders(order_no TEXT PRIMARY KEY,status TEXT,updated_at TEXT); CREATE TABLE IF NOT EXISTS inventory(sku TEXT PRIMARY KEY,quantity INTEGER);")
c.execute("INSERT OR IGNORE INTO orders VALUES ('DEMO001','待发货',datetime('now'))")
c.execute("INSERT OR IGNORE INTO inventory VALUES ('SKU001',100)")
if len(sys.argv)>2 and sys.argv[2]=='update':
 c.execute("UPDATE orders SET status='已发货',updated_at=datetime('now') WHERE order_no='DEMO001'")
 c.execute("UPDATE inventory SET quantity=88 WHERE sku='SKU001'")
c.commit();c.close()
config=f"""kind: source
name: demo-db
type: sqlite
database: {json.dumps(db.as_posix())}
---
kind: tool
name: query_demo_order
type: sqlite-sql
source: demo-db
description: 查询演示订单，数据是模拟数据。示例订单号 DEMO001。
parameters:
  - name: order_id
    type: string
    description: 演示订单号
statement: SELECT order_no,status,updated_at FROM orders WHERE order_no = ? LIMIT 1;
---
kind: tool
name: query_demo_inventory
type: sqlite-sql
source: demo-db
description: 查询模拟库存，示例商品 SKU001。
parameters:
  - name: sku
    type: string
    description: 商品编号
statement: SELECT sku,quantity FROM inventory WHERE sku = ? LIMIT 1;
"""
(root/'tools.yaml').write_text(config,encoding='utf-8')
print(json.dumps({'config':str(root/'tools.yaml')}))
