const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('desktop',{
 call:(name,...args)=>ipcRenderer.invoke('desktop:'+name,...args),
 onState:fn=>ipcRenderer.on('desktop:state',(_,s)=>fn(s)),
 onLog:fn=>ipcRenderer.on('desktop:log',(_,s)=>fn(s))
});
