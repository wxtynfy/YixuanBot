const $=s=>document.querySelector(s);let logText='';
function state(s){$('#path').textContent=s.dataDir||'首次使用，请在 D 盘新建一个数据文件夹。';$('#status').textContent=({stopped:'尚未启动',starting:'正在启动…',running:'运行中',stopping:'正在停止…',error:'启动异常'})[s.phase];$('#message').textContent=s.error||'';$('#credentials').hidden=!s.initialPassword;if(s.initialPassword)$('#credentials').textContent='首次登录：用户名 astrbot；临时密码 '+s.initialPassword+'。登录后请修改密码。';if(s.logs){logText=s.logs.join('');$('#logs').textContent=logText||'等待启动…'}}
window.desktop.onState(state);window.desktop.onLog(s=>{logText=(logText+s).slice(-45000);$('#logs').textContent=logText;$('#logs').scrollTop=$('#logs').scrollHeight});
document.querySelectorAll('[data-act]').forEach(b=>b.addEventListener('click',async()=>{b.disabled=true;try{const r=await window.desktop.call(b.dataset.act);if(!r.ok)$('#message').textContent=r.error;else if(r.value?.phase)state(r.value);else if(typeof r.value==='string')$('#message').textContent=r.value}catch(e){$('#message').textContent=e.message}finally{if(b.dataset.act.startsWith('enterprise'))$('#enterprise-result').textContent=$('#message').textContent;b.disabled=false}}));
window.desktop.call('state').then(r=>state(r.value));

for(const action of ['load','test','save'])$('#enterprise-'+action).addEventListener('click',async()=>{
 const buttons=['load','test','save'].map(a=>$('#enterprise-'+a));buttons.forEach(b=>b.disabled=true);const out=$('#enterprise-result');out.textContent='正在处理…';
 try{const v={url:$('#enterprise-url').value,token:$('#enterprise-token').value,active:$('#enterprise-active').checked,clearToken:$('#enterprise-clear').checked};const r=await window.desktop.call('enterprise'+action[0].toUpperCase()+action.slice(1),v);if(!r.ok)throw Error(r.error);
 if(action==='test')out.textContent='连接成功，可用工具：'+(r.value.tools.join('、')||'无，请检查服务端工具集')+(r.value.truncated?'（列表已截断）':'');
 else {$('#enterprise-url').value=r.value.url;$('#enterprise-active').checked=r.value.active;$('#enterprise-token').value='';$('#enterprise-clear').checked=false;out.textContent=(action==='save'?'已保存，启动机器人后生效。':'已读取。')+(r.value.hasToken?' 已保存认证令牌。':' 未保存认证令牌。');}
 }catch(e){out.textContent=e.message;}finally{buttons.forEach(b=>b.disabled=false);}
});
