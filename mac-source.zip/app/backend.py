"""Desktop lifecycle wrapper; upstream AstrBot remains in vendor/backend."""
import os, sys, asyncio, threading
from pathlib import Path
base=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(base))
os.environ['ASTRBOT_CLI']='1'
from filelock import FileLock
from astrbot.core import LogBroker, LogManager, db_helper, logger
from astrbot.core.initial_loader import InitialLoader

async def main():
    broker=LogBroker();LogManager.set_queue_handler(logger,broker)
    loader=InitialLoader(db_helper,broker)
    task=asyncio.create_task(loader.start())
    loop=asyncio.get_running_loop()
    def control():
        # EOF means the parent desktop has exited: don't leave an orphan bot.
        for line in sys.stdin:
            if line.strip()=='STOP':break
        loop.call_soon_threadsafe(task.cancel)
    threading.Thread(target=control,daemon=True).start()
    try:await task
    except asyncio.CancelledError:pass

with FileLock(str(Path.cwd()/'astrbot.lock'),timeout=1):
    asyncio.run(main())
