const {spawn}=require('child_process');const net=require('net');
function freePort(){return new Promise((res,rej)=>{const s=net.createServer();s.on('error',rej);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>res(p));});});}
class Toolbox{
 constructor(exe){this.exe=exe;this.child=null;this.url='';}
 async start(config){if(this.child)return this.url;const port=await freePort();const p=spawn(this.exe,['--config',config,'--address','127.0.0.1','--port',String(port)],{windowsHide:true,stdio:['ignore','pipe','pipe']});this.child=p;let failed=false;p.stdout.on('data',()=>{});p.stderr.on('data',()=>{});p.on('error',()=>{failed=true;});p.on('exit',()=>{if(this.child===p){this.child=null;this.url='';}});this.url=`http://127.0.0.1:${port}/mcp`;
 for(let i=0;i<100;i++){if(failed||this.child!==p)break;try{await fetch(`http://127.0.0.1:${port}/`,{signal:AbortSignal.timeout(400)});return this.url;}catch{}await new Promise(r=>setTimeout(r,200));}await this.stop();throw Error('Toolbox启动失败，请检查配置、数据库连接和服务程序。');}
 async stop(){const p=this.child;if(!p)return;await new Promise(r=>{const t=setTimeout(r,3000);p.once('exit',()=>{clearTimeout(t);r();});p.kill();});if(this.child===p)this.child=null;this.url='';}
}
module.exports={Toolbox};
