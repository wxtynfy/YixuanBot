const fs=require('fs'),path=require('path');
const KEY='yixuan-enterprise';
function validate(v){
 const u=new URL(v.url);if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.hash)throw Error('请输入有效的 HTTP(S) MCP 地址，不要在地址中放密码。');
 if(u.protocol==='http:'&&!['localhost','127.0.0.1','[::1]'].includes(u.hostname))throw Error('远程服务必须使用 HTTPS；本机可用 HTTP。');
 if(typeof v.token!=='string'||v.token.length>8192||/[\r\n]/.test(v.token))throw Error('认证令牌格式不正确');
 return {url:u.href,transport:'streamable_http',active:!!v.active,headers:v.token?{Authorization:'Bearer '+v.token}:{}};
}
function read(dir){if(!dir)throw Error('请先选择数据目录');const p=path.join(dir,'data','mcp_server.json');return fs.existsSync(p)?JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,'')):{mcpServers:{}};}
function load(dir){const v=read(dir).mcpServers?.[KEY]||{};return {url:v.url||'http://127.0.0.1:5000/mcp',active:v.active??false,hasToken:!!v.headers?.Authorization};}
function resolve(dir,v){const old=read(dir).mcpServers?.[KEY];const token=v.clearToken?'':v.token||(old?.headers?.Authorization||'').replace(/^Bearer /,'');return validate({...v,token});}
function save(dir,v){const entry=resolve(dir,v),doc=read(dir);doc.mcpServers??={};doc.mcpServers[KEY]=entry;const p=path.join(dir,'data','mcp_server.json');fs.mkdirSync(path.dirname(p),{recursive:true});if(fs.existsSync(p))fs.copyFileSync(p,p+'.before-enterprise.bak');const tmp=p+'.tmp';fs.writeFileSync(tmp,JSON.stringify(doc,null,2));fs.renameSync(tmp,p);return load(dir);}
module.exports={validate,load,resolve,save};
