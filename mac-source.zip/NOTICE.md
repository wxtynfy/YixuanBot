# Exion bot 0.1.4

这是基于 AstrBot v4.29.3 的非官方 Windows 桌面发行版。

- 上游：https://github.com/AstrBotDevs/AstrBot
- 固定标签：v4.29.3，提交 f61a7f42696da6df25dc7a249ec9b8d54ed9da18。
- AstrBot 版权归其原作者和贡献者所有；以 AGPL-3.0-or-later 提供。
- 本项目新增 Electron 桌面外壳、生命周期控制、目录选择、备份与托盘，同样以 AGPL-3.0-or-later 提供。
- 自定义名称与图片由使用者提供，不表示 AstrBot 官方背书；图片的权利不由本声明另行授予。
- 对应源码和构建说明位于安装资源目录中的 source-distribution.zip，可通过软件的“查看随附源码”定位。
- Python、Electron 和各依赖保留自身的许可证。Python LICENSE.txt、Electron LICENSE/第三方声明及 Python 包内 dist-info 许可证随运行环境保留。

本版本不包含任何现有用户的 API Key、QQ 登录信息、聊天记录或插件数据。模型服务、平台账号与额外桥接程序需自行配置。

0.1.4 修改：后台品牌图标、名称、首次介绍已定制，移除欢迎页相关资源卡片。保留上游许可证及源码。
