# 奕炫Bot Apple Silicon 构建准备

状态：已适配启动路径、窗口激活、进程退出、Mac 图标及 arm64 DMG 配置。尚未在 macOS 上构建或测试，没有生成可交付 DMG。

在苹果芯片 Mac 安装 Node.js 22+、pnpm 和 uv 后，执行 `bash scripts/build-mac.sh`。
脚本将下载独立 Python 和 macOS 原生依赖，需要网络；任何依赖不可用会立即停止。当前未验证这些依赖在 macOS arm64 上的可用性。

未配置 Apple Developer ID 签名或公证。公司对外分发前应配置签名、公证并验证 Gatekeeper。不要直接绕过安全设置。

构建后须检查：拖入应用程序目录、首次启动、数据目录选择、后台启动、登录、停止、托盘退出、模型调用和所需平台连接。Windows 的 QQ 桥接软件不包含在内。
