# Exion bot 0.1.7 Apple Silicon

已同步新版企业数据库功能、品牌名称和托盘退出修复。通过 GitHub Actions 在 macOS arm64 构建。构建脚本包含真实 Toolbox 模拟数据库测试，失败时不继续打包。

尚需在实际 Mac 上完成首次启动、模型调用、平台连接与 Gatekeeper 验收。未配置 Developer ID 签名和公证，不能声称已通过苹果认证。
